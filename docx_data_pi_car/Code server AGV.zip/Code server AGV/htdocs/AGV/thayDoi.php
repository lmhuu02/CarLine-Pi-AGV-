<!DOCTYPE html>
<html lang="en">
<?php include "database.php"; ?>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="main.css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thay đổi vị trí</title>
    <?php
        if(!empty($_GET['btnSua1'])){
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $dd = $_POST['diaDiem'];
                $kh = $_POST['kyHieu'];
                $uid = $_POST['uid'];
                $query = "UPDATE vitri SET diaDiem = '$dd', viTri = '$kh',UID='$uid',trangthai='chưa đến' where id = 1";
                $result = mysqli_query($con,$query);
                
            }
        }
        elseif(!empty($_GET['btnSua2'])){
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $dd = $_POST['diaDiem'];
                $kh = $_POST['kyHieu'];
                $uid = $_POST['uid'];
                $query = "UPDATE vitri SET diaDiem = '$dd', viTri = '$kh',UID='$uid',trangthai='chưa đến' where id = 2";
                $result = mysqli_query($con,$query);
                
            }
        }
        elseif(!empty($_GET['btnSua3'])){
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $dd = $_POST['diaDiem'];
                $kh = $_POST['kyHieu'];
                $uid = $_POST['uid'];
                $query = "UPDATE vitri SET diaDiem = '$dd', viTri = '$kh',UID='$uid',trangthai='chưa đến' where id = 3";
                $result = mysqli_query($con,$query);
                
            }
        }
        elseif(!empty($_GET['btnSua4'])){
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $dd = $_POST['diaDiem'];
                $kh = $_POST['kyHieu'];
                $uid = $_POST['uid'];
                $query = "UPDATE vitri SET diaDiem = '$dd', viTri = '$kh',UID='$uid',trangthai='chưa đến' where id = 4";
                $result = mysqli_query($con,$query);
                
            }
        }

    ?>
</head>
<body>
    <div><form action="index.php"> <input type="submit" value="quay lại trang chủ"> </form></div>
    <div>
        <table>
            <form method="post">
                <tr>
                    <th id="diaDiem">Địa điểm</th>
                    <th id="kyHieu">Ký hiệu</th>
                    <th id="uid">UID</th>
                </tr>
                <tr>
                    <th><input type="text" name="diaDiem"></th>
                    <th><input type="text" name="kyHieu"></th>
                    <th><input type="text" name="uid"></th>
                    <th><div><input type="submit" name="submit" value="Thay đổi"></div></th>
                </tr>
            </form>
        </table>
    </div>
</body>
</html>