<!DOCTYPE html>
<html lang="en">
<?php include "database.php"; ?>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="main.css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AGV</title>
</head>
<body>
<?php
    header("refresh:1; url=index.php");
    $query2 = "select *from vitri where id = '1'";
    $re2 = mysqli_query($con,$query2);
    while($row2 = mysqli_fetch_array($re2)){
        $o1 = $row2["diaDiem"];   
        $uid1= $row2["UID"]; 
        $kh1= $row2["viTri"]; 
        $trangthai1= $row2["trangthai"]; 
        $soluong1= $row2["soluong"]; 
    }
    $query2 = "select *from vitri where id = '2'";
    $re2 = mysqli_query($con,$query2);
    while($row2 = mysqli_fetch_array($re2)){
        $o2 = $row2["diaDiem"];   
        $uid2= $row2["UID"]; 
        $kh2= $row2["viTri"]; 
        $trangthai2= $row2["trangthai"]; 
        $soluong2= $row2["soluong"]; 
    }
    $query2 = "select *from vitri where id = '3'";
    $re2 = mysqli_query($con,$query2);
    while($row2 = mysqli_fetch_array($re2)){
        $o3 = $row2["diaDiem"];  
        $uid3= $row2["UID"];  
        $kh3= $row2["viTri"]; 
        $trangthai3= $row2["trangthai"]; 
        $soluong3= $row2["soluong"]; 
    }
    $query2 = "select *from vitri where id = '4'";
    $re2 = mysqli_query($con,$query2);
    while($row2 = mysqli_fetch_array($re2)){
        $o4 = $row2["diaDiem"];   
        $uid4= $row2["UID"]; 
        $kh4= $row2["viTri"]; 
        $trangthai4= $row2["trangthai"]; 
        $soluong4= $row2["soluong"]; 
    }
    $query2 = "select *from vitri where id = '5'";
    $re2 = mysqli_query($con,$query2);
    while($row2 = mysqli_fetch_array($re2)){
        $o5 = $row2["diaDiem"];   
        $uid5= $row2["UID"];  
        $trangthai5= $row2["trangthai"]; 
    }
    if(!empty($_POST['btnXoa1'])){
        $query = "UPDATE vitri SET diaDiem = '', viTri = '',UID='',trangthai='' where id = 1";
        $result = mysqli_query($con,$query);
        header("refresh: 0");
    }
    elseif(!empty($_POST['btnXoa2'])){
        $query = "UPDATE vitri SET diaDiem = '', viTri = '',UID='',trangthai='' where id = 2";
        $result = mysqli_query($con,$query);
        header("refresh: 0");
    }
    elseif(!empty($_POST['btnXoa3'])){
        $query = "UPDATE vitri SET diaDiem = '', viTri = '',UID='',trangthai='' where id = 3";
        $result = mysqli_query($con,$query);
        header("refresh: 0");
    }
    elseif(!empty($_POST['btnXoa4'])){
        $query = "UPDATE vitri SET diaDiem = '', viTri = '',UID='',trangthai='' where id = 4";
        $result = mysqli_query($con,$query);
        header("refresh: 0");
    }

    if(!empty($_POST['btnXoa_sl1'])){
        $query = "UPDATE vitri SET soluong=0 where id = 1";
        $result = mysqli_query($con,$query);
        header("refresh: 0");
    }
    elseif(!empty($_POST['btnXoa_sl2'])){
        $query = "UPDATE vitri SET soluong=0 where id = 2";
        $result = mysqli_query($con,$query);
        header("refresh: 0");
    }
    elseif(!empty($_POST['btnXoa_sl3'])){
        $query = "UPDATE vitri SET soluong=0 where id = 3";
        $result = mysqli_query($con,$query);
        header("refresh: 0");
    }
    elseif(!empty($_POST['btnXoa_sl4'])){
        $query = "UPDATE vitri SET soluong=0 where id = 4";
        $result = mysqli_query($con,$query);
        header("refresh: 0");
    }
?>
    <div id="intro"><H1>HỆ THỐNG QUẢN LÝ XE TƯ HÀNH AGV</H1></div>
    <div id="bang">
        <table>
            <tr>
                <th id="diaDiem">Địa điểm</th>
                <th id="uid">UID</th>
                <th id="kyHieu">Ký hiệu</th>
                <th id="trangThai">Trạng thái</th>
                <th id="soLuong">Số lượng</th>
                <th id="chinhSua">chỉnh sửa</th>
            </tr>
            <tr>
                <th><?php echo $o5; ?></th>
                <th><?php echo $uid5; ?></th>
                <th> </th>
                <th><?php echo $trangthai5;?></th>
                <th> </th>
                <th> </th>
            </tr>
            <tr>
                <th><?php echo $o1; ?></th>
                <th><?php echo $uid1; ?></th>
                <th><?php echo $kh1; ?></th>
                <th><?php echo $trangthai1;?></th>
                <th><?php echo $soluong1;?>
                    <table>
                        <th><form method="post"> <input type="submit" name="btnXoa_sl1" value="Xóa"></form></th>
                    </table>
                </th>
                <th>
                    <table>
                        <th><form action="thayDoi.php"> <input type="submit" name="btnSua1" value="sửa"></form></th>
                        <th><form method="post"> <input type="submit" name="btnXoa1" value="Xóa"></form></th>
                    </table>
                </th>
            </tr>
            <tr>
                <th><?php echo $o2; ?></th>
                <th><?php echo $uid2; ?></th>
                <th><?php echo $kh2; ?></th>
                <th><?php echo $trangthai2;?></th>
                <th><?php echo $soluong2;?> 
                    <table>
                        <th><form method="post"> <input type="submit" name="btnXoa_sl2" value="Xóa"></form></th>
                    </table>
                </th>
                <th>
                    <table>
                        <th><form action="thayDoi.php"> <input type="submit" name="btnSua2" value="sửa"></form></th>
                        <th><form method="post"> <input type="submit" name="btnXoa2" value="Xóa"></form></th>        
                    </table>
                </th>
            </tr>
            <tr>
                <th><?php echo $o3; ?></th>
                <th><?php echo $uid3; ?></th>
                <th><?php echo $kh3; ?></th>
                <th><?php echo $trangthai3;?></th>
                <th><?php echo $soluong3;?> 
                    <table>
                        <th><form method="post"> <input type="submit" name="btnXoa_sl3" value="Xóa"></form></th>
                    </table>
                </th>
                <th>
                    <table>
                        <th><form action="thayDoi.php"> <input type="submit" name="btnSua3" value="sửa"></form></th>
                        <th><form method="post"> <input type="submit" name="btnXoa3" value="Xóa"></form></th>        
                    </table>
                </th>
            </tr>
            <tr>
                <th><?php echo $o4; ?></th>
                <th><?php echo $uid4; ?></th>
                <th><?php echo $kh4; ?></th>
                <th><?php echo $trangthai4;?></th>
                <th><?php echo $soluong4;?> 
                    <table>
                        <th><form method="post"> <input type="submit" name="btnXoa_sl4" value="Xóa"></form></th>
                    </table>
                </th>
                <th>
                    <table>
                        <th><form action="thayDoi.php"> <input type="submit" name="btnSua4" value="sửa"></form></th>
                        <th><form method="post"> <input type="submit" name="btnXoa4" value="Xóa"></form></th>        
                    </table>
                </th>
            </tr>

        </table>
    </div>
</body>
</html>
