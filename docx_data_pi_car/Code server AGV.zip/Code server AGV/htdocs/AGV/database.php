<?php
    $severName="localhost";
    $useName="root";
    $pass="";
    $dataBase="agv";
    $con = new mysqli("$severName","$useName","$pass","$dataBase");
    if($con){
       // echo "da ket noi";
    }
    else{
        echo "khong the ket noi";
    }

?>