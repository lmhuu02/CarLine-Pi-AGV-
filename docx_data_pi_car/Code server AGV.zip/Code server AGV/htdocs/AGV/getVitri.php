<?php include "database.php"; ?>
<?php
    $stt=$_GET['stt'];
    if($stt== '1'){
       // echo"gui ve vi tri:" ; 
        $query = "select *from vitri";
        $re = mysqli_query($con,$query);
        while($row = mysqli_fetch_array($re)){
         echo $row['viTri'].' ';   
        }
    }
    if($stt== '2'){
        $nVitri=$_GET['nVitri'];
        $query2 = "select UID from vitri where viTri = '$nVitri'";
        $re2 = mysqli_query($con,$query2);
        while($row2 = mysqli_fetch_array($re2)){  
            $uid= $row2["UID"]; 
        }
        if(!empty($uid)){
            $query2 = "UPDATE dichuyen SET diaDiem = '$uid', run = '1' where id = '1'";
            $result2 = mysqli_query($con,$query2);
            echo"ok";
        }else{
            echo"false";
        }
    }
    if($stt== '3'){
        $query = "select *from dichuyen where id=1";
        $re = mysqli_query($con,$query);
        while($row = mysqli_fetch_array($re)){
          $run=$row['run'];
          $maID = $row['diaDiem'];  
        }
        if($run == 1)
        {
            echo '$'.$maID.'%';
            $query2 = "UPDATE dichuyen SET run = '0' where id = '1'";
            $result2 = mysqli_query($con,$query2);
        }else{
            echo 'None';
        }
    }
    if($stt== '4'){
        $query = "select *from viTri where id=5";
        $re = mysqli_query($con,$query);
        while($row = mysqli_fetch_array($re)){
          echo '@'.$row['UID'].'#';  
        }
    }
    if($stt== '5'){
        $UID_=$_GET['uid'];
        $query = "select *from dichuyen where id=1";
        $re = mysqli_query($con,$query);
        while($row = mysqli_fetch_array($re)){
            $maID = $row['diaDiem'];   
        }
        for($i=1;$i<=5;$i=$i+1)
        {
            $query = "select UID from viTri where id = $i";
            $re = mysqli_query($con,$query);
            $ID = mysqli_fetch_array($re)['UID'];
            if($UID_!=$ID)
            {
                $query = "UPDATE vitri SET trangthai='NG' where id = $i";
                $result = mysqli_query($con,$query);
            }else
            {
                $query = "UPDATE vitri SET trangthai='OK' where id = $i";
                $result = mysqli_query($con,$query);
            }
            if($i != 5 && $maID==$UID_ && $UID_==$ID)
            {
                $query = "select soluong from viTri where id = $i";
                $re = mysqli_query($con,$query);
                while($row = mysqli_fetch_array($re)){
                    $sl = $row['soluong']; 
                    $sl = $sl+1;
                    echo $sl;
                }
                if($sl > 0)
                {
                    $query = "UPDATE vitri SET soluong=$sl  where id =$i";
                    $re = mysqli_query($con,$query);
                   // header("refresh: 0;url=index.php");
                }
                
            }
        }
       echo'None';
    }
?>